def func2(config:dict):
    print('func2 ran')
    print(config['user_config_2'])