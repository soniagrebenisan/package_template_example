def func1(config:dict):
    print("func1 ran")
    print(config['user_config_1'])